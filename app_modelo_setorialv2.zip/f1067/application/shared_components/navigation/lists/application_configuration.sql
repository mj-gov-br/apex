prompt --application/shared_components/navigation/lists/application_configuration
begin
--   Manifest
--     LIST: Application Configuration
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591757339680659714
,p_default_application_id=>1067
,p_default_id_offset=>1607674821888210069
,p_default_owner=>'WS_CURSO10_AL4_010'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(3215493738559409600)
,p_name=>'Application Configuration'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(3215484079346409581)
,p_version_scn=>322305591
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3215494078121409600)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Configuration Options'
,p_list_item_link_target=>'f?p=&APP_ID.:20040:&APP_SESSION.::&DEBUG.:20040::'
,p_list_item_icon=>'fa-sliders'
,p_list_text_01=>'Enable or disable application features'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
