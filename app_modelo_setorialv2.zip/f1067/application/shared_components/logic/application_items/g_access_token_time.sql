prompt --application/shared_components/logic/application_items/g_access_token_time
begin
--   Manifest
--     APPLICATION ITEM: G_ACCESS_TOKEN_TIME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591757339680659714
,p_default_application_id=>1067
,p_default_id_offset=>1607674821888210069
,p_default_owner=>'WS_CURSO10_AL4_010'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(8252909214341942929)
,p_name=>'G_ACCESS_TOKEN_TIME'
,p_protection_level=>'I'
,p_version_scn=>46758555
);
wwv_flow_imp.component_end;
end;
/
