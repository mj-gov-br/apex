prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 1067
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591757339680659714
,p_default_application_id=>1067
,p_default_id_offset=>1607674821888210069
,p_default_owner=>'WS_CURSO10_AL4_010'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(8252852019143275336)
,p_group_name=>unistr('Administra\00E7\00E3o')
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(3215341410254372713)
,p_group_name=>'User Settings'
);
wwv_flow_imp.component_end;
end;
/
