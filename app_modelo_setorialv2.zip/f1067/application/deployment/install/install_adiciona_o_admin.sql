prompt --application/deployment/install/install_adiciona_o_admin
begin
--   Manifest
--     INSTALL: INSTALL-adiciona o admin
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591757339680659714
,p_default_application_id=>1067
,p_default_id_offset=>1607674821888210069
,p_default_owner=>'WS_CURSO10_AL4_010'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3215343468375381923)
,p_install_id=>wwv_flow_imp.id(8253234605461889817)
,p_name=>'adiciona o admin'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_application_id NUMBER;',
'    v_user_name      VARCHAR2(255);',
'BEGIN',
'    --------------------------------------------------------------------',
unistr('    -- ID da aplica\00E7\00E3o durante a instala\00E7\00E3o'),
'    --------------------------------------------------------------------',
'    v_application_id := apex_application_install.get_application_id;',
'',
'    --------------------------------------------------------------------',
unistr('    -- Usu\00E1rio que est\00E1 executando a instala\00E7\00E3o'),
'    --------------------------------------------------------------------',
'    v_user_name := COALESCE(',
'        SYS_CONTEXT(''APEX$SESSION'', ''APP_USER''),',
'        V(''APP_USER''),',
'        USER',
'    );',
'',
'    --------------------------------------------------------------------',
unistr('    -- Adiciona o usu\00E1rio atual \00E0 role padr\00E3o Administrator'),
'    --------------------------------------------------------------------',
'    apex_acl.add_user_role(',
'        p_application_id => v_application_id,',
'        p_user_name      => UPPER(v_user_name),',
'        p_role_static_id => ''ADMINISTRATOR''',
'    );',
'',
'EXCEPTION',
'    WHEN DUP_VAL_ON_INDEX THEN',
'        NULL;',
'',
'    WHEN OTHERS THEN',
'        IF SQLCODE = -20001 THEN',
'            NULL;',
'        ELSE',
'            RAISE;',
'        END IF;',
'END;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
