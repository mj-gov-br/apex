prompt --workspace/credentials/app_1063_push_notifications_credentials
begin
--   Manifest
--     CREDENTIAL: App 1063 Push Notifications Credentials
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>800117127063342546
,p_default_application_id=>159
,p_default_id_offset=>1606732579306459419
,p_default_owner=>'WS_MODELOS'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(10541558004755)
,p_name=>'App 1063 Push Notifications Credentials'
,p_static_id=>'App_1063_Push_Notifications_Credentials'
,p_authentication_type=>'KEY_PAIR'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
