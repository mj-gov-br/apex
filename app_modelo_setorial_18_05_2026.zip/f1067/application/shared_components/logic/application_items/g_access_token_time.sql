prompt --application/shared_components/logic/application_items/g_access_token_time
begin
--   Manifest
--     APPLICATION ITEM: G_ACCESS_TOKEN_TIME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>800117127063342546
,p_default_application_id=>159
,p_default_id_offset=>1606732579306459419
,p_default_owner=>'WS_MODELOS'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(5037571382934574964)
,p_name=>'G_ACCESS_TOKEN_TIME'
,p_protection_level=>'I'
,p_version_scn=>46758555
);
wwv_flow_imp.component_end;
end;
/
