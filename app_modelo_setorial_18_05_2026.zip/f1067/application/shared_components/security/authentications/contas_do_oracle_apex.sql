prompt --application/shared_components/security/authentications/contas_do_oracle_apex
begin
--   Manifest
--     AUTHENTICATION: Contas do Oracle APEX
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>800117127063342546
,p_default_application_id=>159
,p_default_id_offset=>1606732579306459419
,p_default_owner=>'WS_MODELOS'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(5037508425886907334)
,p_name=>'Contas do Oracle APEX'
,p_scheme_type=>'NATIVE_APEX_ACCOUNTS'
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_version_scn=>46711227
);
wwv_flow_imp.component_end;
end;
/
