prompt --application/comments
begin
--   Manifest
--     APPLICATION COMMENTS: 1067
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>800117127063342546
,p_default_application_id=>159
,p_default_id_offset=>1606732579306459419
,p_default_owner=>'WS_MODELOS'
);
null;
wwv_flow_imp.component_end;
end;
/
