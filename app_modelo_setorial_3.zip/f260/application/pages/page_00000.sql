prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>800117127063342546
,p_default_application_id=>260
,p_default_id_offset=>1703471904367626577
,p_default_owner=>'WS_MODELOS'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>unistr('P\00E1gina Global')
,p_step_title=>unistr('P\00E1gina Global')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5442845196463945437)
,p_plug_name=>'topo'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_07'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
unistr('        /* 1. Faixa Azul Superior (Minist\00E9rio) */'),
'        .barra-ministerio {',
'            background-color: #004595; /* Tom de azul oficial */',
'            color: white;',
'            padding: 0px 20px;',
'            display: flex;',
'            align-items: center;',
'            font-size: 14px;',
'        }',
'',
'        .barra-ministerio span {',
'            font-weight: normal;',
'        }',
'',
'        .barra-ministerio strong {',
'            font-weight: bold;',
'            margin-left: 4px;',
'        }',
'</style>',
'<nav>',
'    <header class="barra-ministerio">',
'        <svg viewBox="0 0 100 60" preserveAspectRatio="xMinYMid meet" style="height: 28px; margin-right: 12px; vertical-align: middle;">',
'        <rect width="100" height="60" fill="#004595"/>',
'        ',
'        <g stroke="white" stroke-width="6" stroke-linecap="round">',
'            <line x1="20" y1="5" x2="20" y2="55" />',
'            <line x1="45" y1="5" x2="45" y2="55" />',
'            <line x1="70" y1="5" x2="70" y2="55" />',
'            <line x1="95" y1="5" x2="95" y2="55" />',
'            ',
'            <line x1="20" y1="40" x2="45" y2="40" />',
'            <line x1="45" y1="20" x2="70" y2="20" />',
'        </g>',
'        </svg>',
unistr('        <span>Minist\00E9rio da <strong>Justi\00E7a e Seguran\00E7a P\00FAblica</strong></span>'),
'    </header>',
'</nav>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
