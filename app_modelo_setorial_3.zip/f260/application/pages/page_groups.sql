prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 260
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>800117127063342546
,p_default_application_id=>260
,p_default_id_offset=>1703471904367626577
,p_default_owner=>'WS_MODELOS'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(9956323923510901913)
,p_group_name=>unistr('Administra\00E7\00E3o')
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(4918813314621999290)
,p_group_name=>'User Settings'
);
wwv_flow_imp.component_end;
end;
/
