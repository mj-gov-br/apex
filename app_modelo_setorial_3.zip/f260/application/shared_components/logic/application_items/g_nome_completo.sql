prompt --application/shared_components/logic/application_items/g_nome_completo
begin
--   Manifest
--     APPLICATION ITEM: G_NOME_COMPLETO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>800117127063342546
,p_default_application_id=>260
,p_default_id_offset=>1703471904367626577
,p_default_owner=>'WS_MODELOS'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(9956380147311561984)
,p_name=>'G_NOME_COMPLETO'
,p_protection_level=>'I'
,p_version_scn=>46758402
);
wwv_flow_imp.component_end;
end;
/
