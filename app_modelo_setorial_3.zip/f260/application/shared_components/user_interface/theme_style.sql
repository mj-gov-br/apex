prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 260
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>800117127063342546
,p_default_application_id=>260
,p_default_id_offset=>1703471904367626577
,p_default_owner=>'WS_MODELOS'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(4919032135731104933)
,p_theme_id=>42
,p_name=>'MJSP 2'
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_Accent-BG":"#1351b4","@g_Link-Base":"#1351b4","@g_Focus":"#1351b4","@g_Header-BG":"#ffffff","@g_Header-FG":"#333333","@g_Body-BG":"#fdfdfd","@g_Body-Text":"#333333","@g_Actions-Col-BG":"#f9f9f9","@g_Actions-Col-Text":"#33333'
||'3","@g_Body-Title-BG":"#ffffff","@g_Body-Title-FG":"#333333","@g_Nav-BG":"#1351b4","@g_Nav-FG":"#fdfdfd","@g_Nav-Active-BG":"#1351b4","@g_Nav-Active-FG":"#ffffff","@g_Nav-Icon":"#fdfdfd","@g_Nav-Icon-Active":"#ffffff","@g_Nav-Badge-BG":"#1351b4","@g_'
||'Nav-Badge-FG":"#ffffff","@g_NavBarMenu-Active-BG":"#e6e6e6","@g_NavBarMenu-Active-FG":"#333333","@g_NavBarMenu-BG":"#ffffff","@g_NavBarMenu-FG":"#333333","@g_Nav-Accent-BG":"#e6e6e6","@g_Nav-Accent-FG":"#333333","@g_Region-Header-BG":"#ffffff","@g_Re'
||'gion-Header-FG":"#333333","@Head-Height":"64px","@Nav-Exp":"260px","@g_Accent-OG":"#fbfcff","@l_Button-Hot-BG":"#e6e6e6","@l_Button-Hot-Text":"#0d0d0d","@l_Button-Primary-BG":"#1351b4","@l_Button-Primary-Text":"#ffffff","@l_Button-Simple-BG":"#FFFFFF'
||'","@l_Button-Simple-Text":"#404040","@g_Color-Palette-15":"#6E8598","@g_Color-Palette-15-FG":"#ffffff","@g_Color-Palette-13":"#5a68ad","@g_Color-Palette-13-FG":"#f5f5f5","@g_Color-Palette-1":"#309fdb","@g_Color-Palette-1-FG":"#ffffff"},"customCSS":"@'
||unistr('media (max-width: 768px) { /* Afeta tablets e celulares */\005Cn  ul, ol {\005Cn    padding-left: 10px !important; /* Reduz a indenta\00E7\00E3o padr\00E3o */\005Cn    margin-left: 10px !important; /* Ajusta margem esquerda */\005Cn  }\005Cn\005Cn  li {\005Cn    padding-left: 5px; /* Reduz')
||unistr(' espa\00E7o dentro dos itens da lista */\005Cn    margin-left: 0; /* Remove margens extras */\005Cn  }\005Cn  #t-ContentRow-wrap {\005Cn    padding-left: 5px; /* Reduz espa\00E7o dentro dos itens da lista */\005Cn    margin-left: 0; /* Remove margens extras */\005Cn  }\005Cn}\005Cn@media (')
||unistr('max-width: 768px) and (min-width: 577px) {\005Cn    \005Cn    /* Seleciona somente esta row de bot\00F5es */\005Cn    .row .col.col-2 .t-Button {\005Cn        width: 100% !important;\005Cn        max-width: 100% !important;\005Cn        white-space: normal !important;  /* Permi')
||'te quebra de linha */\n        text-align: center;\n    }\n\n    /* Faz cada coluna virar 100% da largura */\n    .row .col.col-2 {\n        flex: 0 0 100% !important;\n        max-width: 100% !important;\n    }\n}\n\n/* Altera o footer para azul*/\n'
||'.t-Footer {\n  background-color: #1351b4 !important;\n  color: white !important;\n  text-align: center;\n  padding: 10px 0;\n  font-size: 14px;\n}\n.t-Report-wrap , .t-Report-report{\n    width: 100% !important;\n}\nul .t-Tabs{\n    height: 25px !imp'
||'ortant;\n    width: 100% !important;\n}\n.t-Tabs .t-Tabs-item.is-active .t-Tabs-link {\n  background-color: #1351b4 !important;\n  color: #fff !important; /* opcional para contraste */\n}","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#1606714968434224834.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(9956362659827333412)
,p_theme_id=>42
,p_name=>'MJSP'
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_Accent-BG":"#1351b4","@g_Link-Base":"#1351b4","@g_Focus":"#1351b4","@g_Header-BG":"#ffffff","@g_Header-FG":"#333333","@g_Body-BG":"#fdfdfd","@g_Body-Text":"#333333","@g_Actions-Col-BG":"#f9f9f9","@g_Actions-Col-Text":"#33333'
||'3","@g_Body-Title-BG":"#ffffff","@g_Body-Title-FG":"#333333","@g_Nav-BG":"#1351b4","@g_Nav-FG":"#fdfdfd","@g_Nav-Active-BG":"#1351b4","@g_Nav-Active-FG":"#ffffff","@g_Nav-Icon":"#fdfdfd","@g_Nav-Icon-Active":"#ffffff","@g_Nav-Badge-BG":"#1351b4","@g_'
||'Nav-Badge-FG":"#ffffff","@g_NavBarMenu-Active-BG":"#e6e6e6","@g_NavBarMenu-Active-FG":"#333333","@g_NavBarMenu-BG":"#ffffff","@g_NavBarMenu-FG":"#333333","@g_Nav-Accent-BG":"#e6e6e6","@g_Nav-Accent-FG":"#333333","@g_Region-Header-BG":"#ffffff","@g_Re'
||'gion-Header-FG":"#333333","@Head-Height":"64px","@Nav-Exp":"260px","@g_Accent-OG":"#fbfcff","@l_Button-Hot-BG":"#e6e6e6","@l_Button-Hot-Text":"#0d0d0d","@l_Button-Primary-BG":"#1351b4","@l_Button-Primary-Text":"#ffffff","@l_Button-Simple-BG":"#FFFFFF'
||'","@l_Button-Simple-Text":"#404040","@g_Color-Palette-15":"#6E8598","@g_Color-Palette-15-FG":"#ffffff","@g_Color-Palette-13":"#5a68ad","@g_Color-Palette-13-FG":"#f5f5f5","@g_Color-Palette-1":"#309fdb","@g_Color-Palette-1-FG":"#ffffff"},"customCSS":"@'
||unistr('media (max-width: 768px) { /* Afeta tablets e celulares */\005Cn  ul, ol {\005Cn    padding-left: 10px !important; /* Reduz a indenta\00E7\00E3o padr\00E3o */\005Cn    margin-left: 10px !important; /* Ajusta margem esquerda */\005Cn  }\005Cn\005Cn  li {\005Cn    padding-left: 5px; /* Reduz')
||unistr(' espa\00E7o dentro dos itens da lista */\005Cn    margin-left: 0; /* Remove margens extras */\005Cn  }\005Cn  #t-ContentRow-wrap {\005Cn    padding-left: 5px; /* Reduz espa\00E7o dentro dos itens da lista */\005Cn    margin-left: 0; /* Remove margens extras */\005Cn  }\005Cn}\005Cn@media (')
||unistr('max-width: 768px) and (min-width: 577px) {\005Cn    \005Cn    /* Seleciona somente esta row de bot\00F5es */\005Cn    .row .col.col-2 .t-Button {\005Cn        width: 100% !important;\005Cn        max-width: 100% !important;\005Cn        white-space: normal !important;  /* Permi')
||'te quebra de linha */\n        text-align: center;\n    }\n\n    /* Faz cada coluna virar 100% da largura */\n    .row .col.col-2 {\n        flex: 0 0 100% !important;\n        max-width: 100% !important;\n    }\n}\n\n/* Altera o footer para azul*/\n'
||'.t-Footer {\n  background-color: #1351b4 !important;\n  color: white !important;\n  text-align: center;\n  padding: 10px 0;\n  font-size: 14px;\n}\n.t-Report-wrap , .t-Report-report{\n    width: 100% !important;\n}\nul .t-Tabs{\n    height: 25px !imp'
||'ortant;\n    width: 100% !important;\n}\n.t-Tabs .t-Tabs-item.is-active .t-Tabs-link {\n  background-color: #1351b4 !important;\n  color: #fff !important; /* opcional para contraste */\n}\n","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#6644045492530453313.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp.component_end;
end;
/
