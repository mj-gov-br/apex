prompt --application/shared_components/logic/application_items/g_email
begin
--   Manifest
--     APPLICATION ITEM: G_EMAIL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591757339680659714
,p_default_application_id=>1075
,p_default_id_offset=>1606780231072703065
,p_default_owner=>'WS_CURSO10_AL4_010'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(1606785003294706329)
,p_name=>'G_EMAIL'
,p_protection_level=>'I'
,p_version_scn=>322423943
);
wwv_flow_imp.component_end;
end;
/
