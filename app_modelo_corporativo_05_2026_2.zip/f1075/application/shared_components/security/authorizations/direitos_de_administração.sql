prompt --application/shared_components/security/authorizations/direitos_de_administra��o
begin
--   Manifest
--     SECURITY SCHEME: Direitos de Administra��o
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591757339680659714
,p_default_application_id=>1075
,p_default_id_offset=>1606780231072703065
,p_default_owner=>'WS_CURSO10_AL4_010'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(4859818218498418676)
,p_name=>unistr('Direitos de Administra\00E7\00E3o')
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>'return true;'
,p_error_message=>unistr('Privil\00E9gios insuficientes; o usu\00E1rio n\00E3o \00E9 um Administrador')
,p_version_scn=>46711248
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
