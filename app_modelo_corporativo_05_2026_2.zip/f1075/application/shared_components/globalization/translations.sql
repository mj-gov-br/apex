prompt --application/shared_components/globalization/translations
begin
--   Manifest
--     TRANSLATIONS: 1075
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591757339680659714
,p_default_application_id=>1075
,p_default_id_offset=>1606780231072703065
,p_default_owner=>'WS_CURSO10_AL4_010'
);
null;
wwv_flow_imp.component_end;
end;
/
