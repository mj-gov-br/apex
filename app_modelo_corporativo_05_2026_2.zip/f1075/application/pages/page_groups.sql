prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 1075
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591757339680659714
,p_default_application_id=>1075
,p_default_id_offset=>1606780231072703065
,p_default_owner=>'WS_CURSO10_AL4_010'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(4859818497042418677)
,p_group_name=>unistr('Administra\00E7\00E3o')
);
wwv_flow_imp.component_end;
end;
/
