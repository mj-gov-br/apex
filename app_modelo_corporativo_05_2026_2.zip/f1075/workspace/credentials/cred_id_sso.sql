prompt --workspace/credentials/cred_id_sso
begin
--   Manifest
--     CREDENTIAL: cred_id_sso
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591757339680659714
,p_default_application_id=>1075
,p_default_id_offset=>1606780231072703065
,p_default_owner=>'WS_CURSO10_AL4_010'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(4293697946560308744)
,p_name=>'cred_id_sso'
,p_static_id=>'cred_id_sso'
,p_authentication_type=>'OAUTH2_CLIENT_CREDENTIALS'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
