prompt --application/deployment/install/install_funcao_instalacao
begin
--   Manifest
--     INSTALL: INSTALL-funcao_instalacao
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591756289518659390
,p_default_application_id=>1069
,p_default_id_offset=>1607695782438285797
,p_default_owner=>'WS_CURSO10_AL4_009'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(11290081605677642924)
,p_install_id=>wwv_flow_imp.id(11290081128172638182)
,p_name=>'funcao_instalacao'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_condition_type=>'ALWAYS'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  CREATE TABLE "TB_USUARIO" ',
'   (	"NO_USUARIO" VARCHAR2(250), ',
'	"DS_EMAIL" VARCHAR2(250), ',
unistr('	"DS_PERFIL" VARCHAR2(50) DEFAULT ''USU\00C1RIO'', '),
'	"NO_USUARIO_MODIFICACAO" VARCHAR2(150), ',
'	"DH_ULTIMA_MODIFICACAO" TIMESTAMP (6), ',
'	 PRIMARY KEY ("DS_EMAIL")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_TB_USUARIO" ',
'BEFORE INSERT OR UPDATE ON TB_USUARIO',
'FOR EACH ROW',
'BEGIN',
unistr('    -- Atualiza a coluna com o usu\00E1rio logado no APEX'),
'    :NEW.NO_USUARIO_MODIFICACAO := NVL(V(''APP_USER''), USER);',
'    :NEW.DH_ULTIMA_MODIFICACAO := SYSTIMESTAMP;',
'END;',
'/',
'ALTER TRIGGER "TRG_TB_USUARIO" ENABLE;',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
