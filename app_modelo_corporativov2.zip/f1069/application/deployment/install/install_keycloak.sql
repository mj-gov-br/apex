prompt --application/deployment/install/install_keycloak
begin
--   Manifest
--     INSTALL: INSTALL-keycloak
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591756289518659390
,p_default_application_id=>1069
,p_default_id_offset=>1607695782438285797
,p_default_owner=>'WS_CURSO10_AL4_009'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(9284232867673492199)
,p_install_id=>wwv_flow_imp.id(11290081128172638182)
,p_name=>'keycloak'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_condition_type=>'ALWAYS'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'------------------------------------------------------------------------',
'-- AUTOR: IGOR.ARRUDA2@MJ.GOV.BR',
unistr('-- OBJETIVO: Cria\00E7\00E3o da tabela de usu\00E1rios e processo p\00F3s login, conforme padr\00F5es do MJSP'),
'-- DATA: 12/12/2025',
'------------------------------------------------------------------------',
'CREATE OR REPLACE PROCEDURE SP_OAUTH_TOKEN_KEYCLOAK AS',
'',
'    -- Dados do token',
'    NU_EXPIRES_IN     NUMBER;',
'    DS_TOKEN          CLOB;',
'    JK_TOKEN          APEX_JWT.T_TOKEN;',
'',
'    -- Claims relevantes',
'    CO_USUARIO_TOKEN  VARCHAR2(200);',
'    NO_USUARIO_TOKEN  VARCHAR2(500);',
'    DS_EMAIL_TOKEN    VARCHAR2(500);',
'    DH_EXPIRACAO      VARCHAR2(50);',
'',
'BEGIN',
'    --------------------------------------------------------------------',
unistr('    -- Recupera token JSON enviado pelo cliente/aplica\00E7\00E3o'),
'    --------------------------------------------------------------------',
'    DS_TOKEN      := TRIM(apex_json.get_clob(''access_token''));',
'    NU_EXPIRES_IN := apex_json.get_number(''expires_in'');',
'',
'    apex_debug.info(''Token recebido.'');',
'',
'    --------------------------------------------------------------------',
'    -- Valida token',
'    --------------------------------------------------------------------',
'    IF DS_TOKEN IS NULL THEN',
unistr('        RAISE_APPLICATION_ERROR(-20001, ''Access token n\00E3o informado.'');'),
'    END IF;',
'',
'    --------------------------------------------------------------------',
unistr('    -- Define token em item de sess\00E3o'),
'    --------------------------------------------------------------------',
'    apex_util.set_session_state(''G_TOKEN'', DS_TOKEN);',
'',
'    --------------------------------------------------------------------',
'    -- Decodifica o token JWT',
'    --------------------------------------------------------------------',
'    JK_TOKEN := apex_jwt.decode(p_value => DS_TOKEN);',
'',
'    CO_USUARIO_TOKEN := json_value(JK_TOKEN.payload, ''$.sub'');',
'    NO_USUARIO_TOKEN := json_value(JK_TOKEN.payload, ''$.name'');',
'    DS_EMAIL_TOKEN   := LOWER(json_value(JK_TOKEN.payload, ''$.email''));',
'    DH_EXPIRACAO     := json_value(JK_TOKEN.payload, ''$.exp'');',
'',
'    --------------------------------------------------------------------',
'    -- Valida e-mail',
'    --------------------------------------------------------------------',
'    IF DS_EMAIL_TOKEN IS NULL THEN',
unistr('        RAISE_APPLICATION_ERROR(-20002, ''Claim email n\00E3o encontrado no token.'');'),
'    END IF;',
'',
'    --------------------------------------------------------------------',
unistr('    -- Armazena dados na sess\00E3o APEX'),
'    --------------------------------------------------------------------',
'    apex_util.set_session_state(''G_NOME_COMPLETO'', UPPER(NO_USUARIO_TOKEN));',
'    apex_util.set_session_state(''G_EMAIL'', DS_EMAIL_TOKEN);',
'    apex_util.set_session_state(''G_ACCESS_TOKEN_TIME'', DH_EXPIRACAO);',
'',
'    --------------------------------------------------------------------',
'    -- MERGE NA TABELA TB_USUARIO',
'    --------------------------------------------------------------------',
'    MERGE INTO TB_USUARIO U',
'    USING (',
'        SELECT',
'            NO_USUARIO_TOKEN AS NO_USUARIO,',
'            DS_EMAIL_TOKEN   AS DS_EMAIL',
'        FROM DUAL',
'    ) SRC',
'    ON (',
'        LOWER(U.DS_EMAIL) = LOWER(SRC.DS_EMAIL)',
'    )',
'    WHEN MATCHED THEN',
'        UPDATE SET',
'            U.NO_USUARIO = SRC.NO_USUARIO',
'    WHEN NOT MATCHED THEN',
'        INSERT (',
'            NO_USUARIO,',
'            DS_EMAIL',
'        ) VALUES (',
'            SRC.NO_USUARIO,',
'            SRC.DS_EMAIL',
'        );',
'',
unistr('    apex_debug.info(''Usu\00E1rio atualizado/inserido: %s'', DS_EMAIL_TOKEN);'),
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_debug.error(''Erro na SP_OAUTH_TOKEN_KEYCLOAK: %s'', SQLERRM);',
'        RAISE;',
'END SP_OAUTH_TOKEN_KEYCLOAK;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
