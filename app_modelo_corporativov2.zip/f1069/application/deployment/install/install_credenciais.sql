prompt --application/deployment/install/install_credenciais
begin
--   Manifest
--     INSTALL: INSTALL-credenciais
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591756289518659390
,p_default_application_id=>1069
,p_default_id_offset=>1607695782438285797
,p_default_owner=>'WS_CURSO10_AL4_009'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(10531059960596555076)
,p_install_id=>wwv_flow_imp.id(11290081128172638182)
,p_name=>'credenciais'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_condition_type=>'ALWAYS'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    apex_credential.set_persistent_credentials(',
'        p_credential_static_id  => ''cred_id_sso'',',
'        p_client_id             => ''fab0e672-cf42-4fbf-88ec-3ecead1b343e'',',
'        p_client_secret         => ''Z1N8Q~cI2FIKBdkkzqrv6rNIDaH2nrl1dVexxbvl'' ',
'    );',
'    COMMIT;',
'    apex_credential.set_persistent_credentials(',
'        p_credential_static_id  => ''cred_keycloak'',',
'        p_client_id             => ''Apex App Modelo'',',
'        p_client_secret         => ''fgkZXdemnQWs74flcsnLkNr1AgefqfOU'' ',
'    );',
'    COMMIT;    ',
'END;    '))
);
wwv_flow_imp.component_end;
end;
/
