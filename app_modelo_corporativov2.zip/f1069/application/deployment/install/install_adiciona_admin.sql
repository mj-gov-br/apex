prompt --application/deployment/install/install_adiciona_admin
begin
--   Manifest
--     INSTALL: INSTALL-adiciona admin
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591756289518659390
,p_default_application_id=>1069
,p_default_id_offset=>1607695782438285797
,p_default_owner=>'WS_CURSO10_AL4_009'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(4823077157717816213)
,p_install_id=>wwv_flow_imp.id(11290081128172638182)
,p_name=>'adiciona admin'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_application_id NUMBER;',
'    v_user_name      VARCHAR2(255);',
'    v_email          VARCHAR2(255);',
'BEGIN',
'    --------------------------------------------------------------------',
unistr('    -- ID da aplica\00E7\00E3o durante instala\00E7\00E3o'),
'    --------------------------------------------------------------------',
'    v_application_id := apex_application_install.get_application_id;',
'',
'    --------------------------------------------------------------------',
unistr('    -- Usu\00E1rio atual'),
'    --------------------------------------------------------------------',
'    v_user_name := COALESCE(',
'                        SYS_CONTEXT(''APEX$SESSION'', ''APP_USER''),',
'                        V(''APP_USER''),',
'                        USER',
'                    );',
'',
'    v_email := LOWER(v_user_name);',
'',
'    --------------------------------------------------------------------',
unistr('    -- Adiciona usu\00E1rio na role ADMINISTRATOR do APEX'),
'    --------------------------------------------------------------------',
'    BEGIN',
'        apex_acl.add_user_role(',
'            p_application_id => v_application_id,',
'            p_user_name      => UPPER(v_user_name),',
'            p_role_static_id => ''ADMINISTRATOR''',
'        );',
'    EXCEPTION',
'        WHEN OTHERS THEN',
'            IF SQLCODE != -20001 THEN',
'                RAISE;',
'            END IF;',
'    END;',
'',
'    --------------------------------------------------------------------',
unistr('    -- Insere usu\00E1rio na tabela TB_USUARIO'),
'    --------------------------------------------------------------------',
'    MERGE INTO TB_USUARIO t',
'    USING (',
'        SELECT v_user_name AS no_usuario,',
'               v_email     AS ds_email',
'          FROM dual',
'    ) s',
'    ON (',
'        LOWER(t.ds_email) = LOWER(s.ds_email)',
'    )',
'    WHEN MATCHED THEN',
'        UPDATE SET',
'            t.no_usuario = s.no_usuario,',
'            t.ds_perfil  = ''ADMINISTRADOR''',
'    WHEN NOT MATCHED THEN',
'        INSERT (',
'            no_usuario,',
'            ds_email,',
'            ds_perfil',
'        )',
'        VALUES (',
'            s.no_usuario,',
'            s.ds_email,',
'            ''ADMINISTRADOR''',
'        );',
'',
'    COMMIT;',
'',
'END;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
