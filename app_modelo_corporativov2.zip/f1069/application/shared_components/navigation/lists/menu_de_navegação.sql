prompt --application/shared_components/navigation/lists/menu_de_navega��o
begin
--   Manifest
--     LIST: Menu de Navega��o
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591756289518659390
,p_default_application_id=>1069
,p_default_id_offset=>1607695782438285797
,p_default_owner=>'WS_CURSO10_AL4_009'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(11289693544270023668)
,p_name=>unistr('Menu de Navega\00E7\00E3o')
,p_list_status=>'PUBLIC'
,p_version_scn=>322473273
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(11289705315292023719)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('In\00EDcio')
,p_list_item_link_target=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6429933639062652155)
,p_list_item_display_sequence=>10000
,p_list_item_link_text=>'Administracao'
,p_list_item_link_target=>'f?p=&APP_ID.:10000:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-user-wrench'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10000'
);
wwv_flow_imp.component_end;
end;
/
