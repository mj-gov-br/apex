prompt --application/shared_components/navigation/tabs/standard
begin
--   Manifest
--     TABS: 1069
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591756289518659390
,p_default_application_id=>1069
,p_default_id_offset=>1607695782438285797
,p_default_owner=>'WS_CURSO10_AL4_009'
);
null;
wwv_flow_imp.component_end;
end;
/
