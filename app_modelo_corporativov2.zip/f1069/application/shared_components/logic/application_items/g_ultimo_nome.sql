prompt --application/shared_components/logic/application_items/g_ultimo_nome
begin
--   Manifest
--     APPLICATION ITEM: G_ULTIMO_NOME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591756289518659390
,p_default_application_id=>1069
,p_default_id_offset=>1607695782438285797
,p_default_owner=>'WS_CURSO10_AL4_009'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(11289755148530684856)
,p_name=>'G_ULTIMO_NOME'
,p_protection_level=>'I'
,p_version_scn=>46758452
);
wwv_flow_imp.component_end;
end;
/
