prompt --application/shared_components/logic/application_settings
begin
--   Manifest
--     APPLICATION SETTINGS: 1069
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591756289518659390
,p_default_application_id=>1069
,p_default_id_offset=>1607695782438285797
,p_default_owner=>'WS_CURSO10_AL4_009'
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(6429897118239652073)
,p_name=>'ACCESS_CONTROL_SCOPE'
,p_value=>'ALL_USERS'
,p_is_required=>'N'
,p_valid_values=>'ACL_ONLY, ALL_USERS'
,p_on_upgrade_keep_value=>true
,p_required_patch=>wwv_flow_imp.id(6429896816223652072)
,p_comments=>'The default access level given to authenticated users who are not in the access control list'
,p_version_scn=>322495152
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(6429942494445653751)
,p_name=>'FEEDBACK_ATTACHMENTS_YN'
,p_value=>'Y'
,p_is_required=>'N'
,p_valid_values=>'Y, N'
,p_on_upgrade_keep_value=>true
,p_required_patch=>wwv_flow_imp.id(6429942159324653751)
,p_version_scn=>322473552
);
wwv_flow_imp.component_end;
end;
/
