prompt --application/shared_components/security/authentications/keycloak
begin
--   Manifest
--     AUTHENTICATION: keycloak
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591756289518659390
,p_default_application_id=>1069
,p_default_id_offset=>1607695782438285797
,p_default_owner=>'WS_CURSO10_AL4_009'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(9284231840328469425)
,p_name=>'keycloak'
,p_scheme_type=>'NATIVE_SOCIAL'
,p_attribute_01=>wwv_flow_imp.id(2230528638848055034)
,p_attribute_02=>'OAUTH2'
,p_attribute_04=>'https://sso.mj.gov.br/auth/realms/HML/protocol/openid-connect/auth'
,p_attribute_05=>'https://sso.mj.gov.br/auth/realms/HML/protocol/openid-connect/token'
,p_attribute_07=>'email profile'
,p_attribute_09=>'preferred_username'
,p_attribute_11=>'Y'
,p_attribute_12=>'BASIC_AND_CLID'
,p_attribute_13=>'Y'
,p_invalid_session_type=>'LOGIN'
,p_post_auth_process=>'SP_OAUTH_TOKEN_KEYCLOAK'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_version_scn=>322490329
);
wwv_flow_imp.component_end;
end;
/
