prompt --application/shared_components/security/authorizations/administration_rights
begin
--   Manifest
--     SECURITY SCHEME: Administration Rights
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591756289518659390
,p_default_application_id=>1069
,p_default_id_offset=>1607695782438285797
,p_default_owner=>'WS_CURSO10_AL4_009'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(6429897693497652073)
,p_name=>'Administration Rights'
,p_scheme_type=>'NATIVE_EXISTS'
,p_attribute_01=>'select 1 from TB_USUARIO  where ds_perfil  = ''ADMINISTRADOR'' and lower(ds_email) = lower(:APP_USER);'
,p_error_message=>'Insufficient privileges, user is not an Administrator'
,p_version_scn=>323054823
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
