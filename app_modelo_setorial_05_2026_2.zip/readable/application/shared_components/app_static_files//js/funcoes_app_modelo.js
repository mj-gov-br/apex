function redirecionar(pagina,nome_campo,texto) {
    console.log('redicionar para a página ' + pagina);
    apex.server.process(
        "PREPARAR_URL",
        { 
             x01:pagina
            ,x02:nome_campo
            ,x03:texto 
        },{
            success: function(pData) {
                console.log(pData);
                apex.navigation.redirect(pData);
            },
            dataType:'text'
        }
    );
}
function substituirCaracteres(itemName) {
  const apexItem = apex.item(itemName);
  if (!apexItem) return;

  let texto = apexItem.getValue();

  // Substitui aspas tipográficas “ e ” por aspas duplas "
  texto = texto.replace(/[“”]/g, '"');
  texto = texto.replace(/[‘’]/g, '`');

  // Substitui travessão — por traço simples -
  texto = texto.replace(/[–—]/g, '-');

  apexItem.setValue(texto, texto,  true);
  console.log('substituições realizadas');
}

function download(id_arquivo_container,nome_arquivo,p_mime_type) {
console.log('download do arquivo ' + id_arquivo_container);
    apex.server.process(
        "DOWNLOAD",
        { 
             x01:id_arquivo_container
        },{
            success: function(pData) {
               
            var base64Data = pData.arquivo;
            var a = document.createElement("a"); 
            a.href = "data:"+p_mime_type+";base64," + base64Data; 
            a.download = nome_arquivo; 
            a.click(); 

            },
            dataType:'json'
        }
    );
}

function apagar(id_arquivo_container,nome_regiao) {
console.log('apagar arquivo ' + id_arquivo_container);
    apex.server.process(
        "APAGAR",
        { 
             x01:id_arquivo_container
        },{
            success: function(pData) {
                console.log(pData);
               
            //var base64Data = pData.arquivo;
            apex.region(nome_regiao).refresh();

            },
            dataType:'json'
        }
    );
}



/*
    função para fazer o download de uma região HTML como pdf

*/function baixar_pdf(regiao) {

    const today = new Date();
    apex.message.showPageSuccess("O download iniciará automaticamente.");

    const data_atual = formatDate(today, 'dd-mm-aaaa');
    var id_documento = $v('P26_ID_SISTEMA');
    const element = document.querySelector('#' + regiao);

    // ocultar elementos antes de baixar
    const botoes = document.querySelectorAll('.ocultar_baixar_pdf');

    botoes.forEach(function(btn){
        btn.style.display = 'none';
    });

    // spinner APEX
    const spinner$ = apex.util.showSpinner();

    const pdf = new window.jspdf.jsPDF({
        orientation: 'p',
        unit: 'pt',
        format: 'a4'
    });

    pdf.html(element, {
        callback: function (pdf) {

            const totalPages = pdf.internal.getNumberOfPages();

            for (let i = 1; i <= totalPages; i++) {

                pdf.setPage(i);

                // Cabeçalho
                const reservadoText = 'RESERVADO';
                const reservadoTextX = pdf.internal.pageSize.getWidth() / 2;
                const reservadoTextY = 20;

                pdf.setTextColor(231, 43, 16);
                pdf.text(reservadoText, reservadoTextX, reservadoTextY, { align: 'center' });

                // Rodapé página
                pdf.setFontSize(8);
                pdf.setTextColor(0, 0, 0);
                pdf.text(
                    `Página ${i} de ${totalPages}`,
                    pdf.internal.pageSize.getWidth() - 40,
                    pdf.internal.pageSize.getHeight() - 20,
                    { align: 'right' }
                );

                // Rodapé segurança
                const rodapeY = pdf.internal.pageSize.getHeight() - 60;

                const textRodape = [
                    'A fim de preservar os dados relativos aos sistemas do MJSP, o acesso e a divulgação deste documento são reservados.',
                    'Qualquer difusão deverá ser expressamente autorizada pela unidade gestora.'
                ];

                const textX = pdf.internal.pageSize.getWidth() / 2;

                pdf.setTextColor(231, 43, 16);

                textRodape.forEach((line, index) => {
                    pdf.text(line, textX, rodapeY + (index * 10), { align: 'center' });
                });
            }

            pdf.save(`VISÃO ${id_documento} - ${data_atual}.pdf`);

            // remover spinner
            if (spinner$) {
                spinner$.remove();
            }

            // exibir elementos novamente
            botoes.forEach(function(btn){
                btn.style.display = '';
            });

        },

        x: 10,
        y: 10,
        margin: [20, 0.1, 80, 30],
        autoPaging: 'text',
        width: 520,
        windowWidth: 1000
    });
}


function formatDate(date, format) {

    const map = {
        mm: date.getMonth() + 1,
        dd: date.getDate(),
        aa: date.getFullYear().toString().slice(-2),
        aaaa: date.getFullYear()
    };

    return format.replace(/mm|dd|aa|aaaa/gi, matched => map[matched]);

}

document.addEventListener("DOMContentLoaded", function () {
    // Seleciona o rodapé
    var footer = document.querySelector(".t-Footer-body");

    if (footer) {
        // Cria a nova div
        var newDiv = document.createElement("div");

        // Cria a imagem
        var img = document.createElement("img");
        img.src = "https://apps.mj.gov.br/r/ws_20250414084700/141/files/static/v162/logoMJ.png"; // Caminho da imagem
        img.alt = "Logo MJ"; // Texto alternativo
        img.style.maxHeight = "50px"; // Ajuste opcional do tamanho da imagem

        // Adiciona a imagem dentro da nova div
        newDiv.appendChild(img);

        // Adiciona a nova div como primeiro filho do rodapé
        footer.prepend(newDiv);
    }
});
document.querySelectorAll('a.t-Breadcrumb-label').forEach(el => {
    if (el.innerText.trim() === "Início") {
        el.innerHTML = '<span aria-hidden="true" class="fa fa-home"></span>';
    }
    if (el.innerText.trim() === "Administração") {
        el.innerHTML = '<span aria-hidden="true" class="fa fa-gear"></span>';
    }
});

  /* ========= Função de Confete ========= */
function launchConfetti() {
    const duration = 3 * 1000; // duração da animação (3 segundos)
    const end = Date.now() + duration;
    (function frame() {
    // Lança confetes dos dois lados
    confetti({
        particleCount: 3,
        angle: 60,
        spread: 55,
        origin: { x: 0 }
    });
    confetti({
        particleCount: 3,
        angle: 120,
        spread: 55,
        origin: { x: 1 }
    });
    // Continua até o tempo acabar
    if (Date.now() < end) {
        requestAnimationFrame(frame);
    }
    })();
}