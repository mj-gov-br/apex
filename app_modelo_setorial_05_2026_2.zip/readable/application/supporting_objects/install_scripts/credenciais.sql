BEGIN
    apex_credential.set_persistent_credentials(
        p_credential_static_id  => 'cred_id_sso',
        p_client_id             => 'fab0e672-cf42-4fbf-88ec-3ecead1b343e',
        p_client_secret         => 'Z1N8Q~cI2FIKBdkkzqrv6rNIDaH2nrl1dVexxbvl' 
    );
    COMMIT;
END;    