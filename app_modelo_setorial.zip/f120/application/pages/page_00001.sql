prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>8091250338790123
,p_default_application_id=>120
,p_default_id_offset=>623307052329034404
,p_default_owner=>'WS_LOW_CODE'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('In\00EDcio')
,p_alias=>'HOME'
,p_step_title=>'&APP_NAME.'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(744632551429564209)
,p_plug_name=>unistr('Orienta\00E7\00F5es')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="R16033378690432469" class="">    <h1>',
'    DIRETRIZES PARA O DESENVOLVIMENTO LC',
'    </h1>',
'  <hr style="color: #FFD000; border-top: 4px solid #FFD000">',
unistr('    <p>Considerando a import\00E2ncia de se estabelecer as boas pr\00E1ticas no uso da plataforma APEX para desenvolvimento de aplica\00E7\00F5es, cada aplicativo desenvolvido, independente de se tratar de solu\00E7\00E3o setorial ou corporativa, deve, dentre as demais medi')
||'das repassadas pela unidade coordenadora:</p>',
'    <ul style="list-style-type: disc;margin-left: 82.7px;">',
unistr('        <li>Seguir os fundamentos de <strong>identidade visual</strong> adotados pelo Governo Federal e MJSP, sendo este um fator respons\00E1vel por criar <strong>consist\00EAncia</strong> e por garantir a <strong>coes\00E3o</strong> nas comunica\00E7\00F5es digitais o')
||unistr('u f\00EDsicas, trazendo <strong>reconhecimento e credibilidade</strong> para o servi\00E7o oferecido, por meio do uso de cores, tipografia, e outros elementos gr\00E1ficos. Tal medida visa trazer melhor usabilidade aos usu\00E1rios que possuem experi\00EAncia com os dem')
||unistr('ais servi\00E7os digitais do \00F3rg\00E3o.</li>'),
unistr('        <li>Seguir o <strong>padr\00E3o de autentica\00E7\00E3o</strong> de usu\00E1rios definidos pela STI, bem como possuir, se for o caso, regras de permiss\00E3o e perfil de acesso definidos, observando os demais padr\00F5es de seguran\00E7a estabelecidos pela STI.</li>'),
unistr('        <li>Seguir os <strong>padr\00F5es de nomenclatura</strong> <strong>de objetos de Modelo de Dados</strong> <strong>Relacional</strong>, para garantir a compreens\00E3o, a consist\00EAncia e a manuten\00E7\00E3o adequada do modelo de dados ao longo do tempo e entr')
||unistr('e os diferentes sistemas e departamentos, al\00E9m de gerar melhor <strong>qualidade dos dados</strong> por meio do uso de regras de valida\00E7\00E3o, n\00E3o replicar desnecessariamente dados j\00E1 existentes no banco de dados do MJSP.</li>'),
unistr('        <li>Seguir os <strong>padr\00F5es de armazenamento de arquivos</strong> em servidor de arquivos especificado pela STI.</li>'),
unistr('        <li>Seguir os padr\00F5es de seguran\00E7a exigidos quanto ao uso de API''s internas: <strong>\00E9 vedada a cria\00E7\00E3o de APIs no workspace do projeto sem autentica\00E7\00E3o</strong>. Ou seja, toda API criada deve ter autentica\00E7\00E3o b\00E1sica (usu\00E1rio e senha) ou por ')
||unistr('meio de tokens de acesso. A documenta\00E7\00E3o da API deve ser informada na documenta\00E7\00E3o m\00EDnima (documento de vis\00E3o geral) do projeto. </li>'),
unistr('        <li>At\00E9 a determina\00E7\00E3o, pela unidade coordenadora, sobre as diretrizes para uso de intelig\00EAncia artificial nos sistemas do MJSP, <strong>\00E9 vedado o uso das funcionalidades de intelig\00EAncia artificial</strong> nos projetos desenvolvidos em Low ')
||'Code. </li>',
unistr('        <li>At\00E9 a determina\00E7\00E3o, pela unidade coordenadora, sobre as diretrizes para uso de plugins nos sistemas do MJSP, <strong>\00E9 vedado o uso de plugins externos (de terceiros al\00E9m da Oracle)</strong> nos projetos em desenvolvimento com Low Code Ap')
||'ex. </li>',
'    </ul>',
unistr('    <p><strong>Todo aplicativo LC deve ser desenvolvimento no ambiente n\00E3o produtivo, e, ap\00F3s an\00E1lise pela unidade de coordena\00E7\00E3o e governan\00E7a, migrado para uso no ambiente de produ\00E7\00E3o</strong>.</p>'),
unistr('    <p>Acesse <strong><a href="https://acelera.mj.gov.br" target="_blank">acelera.mj.gov.br</a></strong> para atualizar as informa\00E7\00F5es de seu projeto, solicitar suporte ou saber mais sobre as diretrizes do desenvolvimento descentralizado.</p>'),
'',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
