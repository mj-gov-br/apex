prompt --application/shared_components/logic/application_items/g_nome_completo
begin
--   Manifest
--     APPLICATION ITEM: G_NOME_COMPLETO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>8091250338790123
,p_default_application_id=>120
,p_default_id_offset=>623307052329034404
,p_default_owner=>'WS_LOW_CODE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(758697496756141168)
,p_name=>'G_NOME_COMPLETO'
,p_protection_level=>'I'
,p_version_scn=>46758402
);
wwv_flow_imp.component_end;
end;
/
