prompt --application/shared_components/globalization/language
begin
--   Manifest
--     LANGUAGE MAP: 120
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>8091250338790123
,p_default_application_id=>120
,p_default_id_offset=>623307052329034404
,p_default_owner=>'WS_LOW_CODE'
);
null;
wwv_flow_imp.component_end;
end;
/
