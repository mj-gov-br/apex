prompt --application/shared_components/navigation/lists/user_interface
begin
--   Manifest
--     LIST: User Interface
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>800117127063342546
,p_default_application_id=>159
,p_default_id_offset=>806335539314445500
,p_default_owner=>'WS_MODELOS'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(2408285682864011781)
,p_name=>'User Interface'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(2408278175642011754)
,p_version_scn=>164140773
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2408286024697011781)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Op\00E7\00F5es de tema')
,p_list_item_link_target=>'f?p=&APP_ID.:10010:&APP_SESSION.::&DEBUG.:10010::'
,p_list_item_icon=>'fa-paint-brush'
,p_list_text_01=>'Set the default application look and feel'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
