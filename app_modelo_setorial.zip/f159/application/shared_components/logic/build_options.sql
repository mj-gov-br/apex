prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 159
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>800117127063342546
,p_default_application_id=>159
,p_default_id_offset=>806335539314445500
,p_default_owner=>'WS_MODELOS'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(2408278175642011754)
,p_build_option_name=>'Feature: Theme Style Selection'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>164140769
,p_feature_identifier=>'APPLICATION_THEME_STYLE_SELECTION'
,p_build_option_comment=>'Allow administrators to select a default color scheme (theme style) for the application. Administrators can also choose to allow end users to choose their own theme style. '
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(5037508146591907333)
,p_build_option_name=>'Comentado'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>46711227
);
wwv_flow_imp.component_end;
end;
/
