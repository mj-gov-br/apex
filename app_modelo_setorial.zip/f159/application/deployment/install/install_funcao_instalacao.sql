prompt --application/deployment/install/install_funcao_instalacao
begin
--   Manifest
--     INSTALL: INSTALL-funcao_instalacao
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>800117127063342546
,p_default_application_id=>159
,p_default_id_offset=>806335539314445500
,p_default_owner=>'WS_MODELOS'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(5037897251559526594)
,p_install_id=>wwv_flow_imp.id(5037896774054521852)
,p_name=>'funcao_instalacao'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_condition_type=>'ALWAYS'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE TB_USUARIO (',
'    NO_USUARIO VARCHAR2(250),',
'    DS_EMAIL   VARCHAR2(250) PRIMARY KEY,',
unistr('    DS_PERFIL  VARCHAR2(50) DEFAULT ''USU\00C1RIO'','),
'    NO_USUARIO_MODIFICACAO VARCHAR2(150),',
'    DH_ULTIMA_MODIFICACAO TIMESTAMP',
unistr('    -- Adicione outras colunas, como uma para definir o perfil de cada usu\00E1rio'),
');',
'/',
'CREATE OR REPLACE TRIGGER TRG_TB_USUARIO',
'BEFORE INSERT OR UPDATE ON TB_USUARIO',
'FOR EACH ROW',
'BEGIN',
unistr('    -- Atualiza a coluna com o usu\00E1rio logado no APEX'),
'    :NEW.NO_USUARIO_MODIFICACAO := NVL(V(''APP_USER''), USER);',
'    :NEW.DH_ULTIMA_MODIFICACAO := SYSTIMESTAMP;',
'END;',
'/',
'CREATE OR REPLACE PROCEDURE prc_oauth_token ',
'AS ',
'    l_expires_in NUMBER;',
'    l_token VARCHAR2(4000); ',
'    l_token_decoded apex_jwt.t_token; ',
'    l_count PLS_INTEGER;',
'    v_app_id VARCHAR2(10) := V(''APP_ID'');  ',
'    v_session_id VARCHAR2(100) := V(''SESSION''); ',
'',
'    v_nome_completo VARCHAR2(250);',
'    v_email         VARCHAR2(250);',
'BEGIN ',
'    /*',
unistr('        ESSE PROCEDIMENTO \00C9 CHAMADO COM O LOGIN SSO MICROSOFT, '),
unistr('        ELE RECEBE O TOKEN DO USU\00C1RIO, '),
unistr('        E COLOCA ITENS DE SESS\00C3O.'),
'',
unistr('        TAMB\00C9M INSERE OU ATUALIZA O USU\00C1RIO NA TB_USUARIO'),
'    */',
'',
'    l_count := apex_json.get_count(p_path => ''.'');  ',
'    apex_debug.info(''Elementos no JSON: %s'', l_count); ',
'',
'    l_token := TRIM(apex_json.get_clob(''access_token'')); ',
'    l_expires_in := apex_json.get_number(''expires_in'');',
'    apex_debug.info(''Token recuperado (JSON): %s'', l_token); ',
'',
'    apex_util.set_session_state(''G_TOKEN'', l_token); ',
'',
'    -- Decodifica o token',
'    l_token_decoded := apex_jwt.decode(p_value => l_token); ',
'    apex_debug.message(''Payload: '' || l_token_decoded.payload); ',
'',
unistr('    -- Extrai informa\00E7\00F5es do payload'),
'    v_nome_completo := UPPER(json_value(l_token_decoded.payload, ''$.name''));',
'    v_email := LOWER(json_value(l_token_decoded.payload, ''$.preferred_username''));',
'',
'    apex_util.set_session_state(''G_NOME_COMPLETO'', v_nome_completo); ',
'    apex_util.set_session_state(''G_PRENOME'', json_value(l_token_decoded.payload, ''$.given_name'')); ',
'    apex_util.set_session_state(''G_ULTIMO_NOME'', json_value(l_token_decoded.payload, ''$.family_name'')); ',
'    apex_util.set_session_state(''G_IP_ADD'', json_value(l_token_decoded.payload, ''$.ipaddr'')); ',
'    apex_util.set_session_state(''G_ACCESS_TOKEN_TIME'', json_value(l_token_decoded.payload, ''$.exp'')); ',
'',
unistr('    -- Salva ou atualiza usu\00E1rio'),
'    MERGE INTO TB_USUARIO u',
'    USING (SELECT ',
'               v_nome_completo AS NO_USUARIO,',
'               v_email AS DS_EMAIL',
'           FROM dual) src',
'    ON (lower(u.DS_EMAIL) = lower(src.DS_EMAIL))',
'    WHEN MATCHED THEN',
'        UPDATE SET ',
'            u.NO_USUARIO = src.NO_USUARIO,',
'            u.NO_USUARIO_MODIFICACAO = NVL(V(''APP_USER''), USER),',
'            u.DH_ULTIMA_MODIFICACAO = SYSTIMESTAMP',
'    WHEN NOT MATCHED THEN',
'        INSERT (NO_USUARIO, DS_EMAIL,  DS_PERFIL)',
unistr('        VALUES (src.NO_USUARIO, lower(src.DS_EMAIL), ''USU\00C1RIO'');'),
'',
unistr('    apex_debug.info(''Usu\00E1rio %s inserido/atualizado na TB_USUARIO'', v_email);'),
'',
'EXCEPTION ',
'    WHEN OTHERS THEN ',
'        apex_debug.error(''Erro ao recuperar token: %s'', SQLERRM); ',
'END prc_oauth_token;',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
