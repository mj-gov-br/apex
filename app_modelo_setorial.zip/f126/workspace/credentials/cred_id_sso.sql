prompt --workspace/credentials/cred_id_sso
begin
--   Manifest
--     CREDENTIAL: cred_id_sso
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>416943639723963931
,p_default_application_id=>126
,p_default_id_offset=>623789507462654173
,p_default_owner=>'WS_CURSO05_PROFESSORES'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(1880644630348565039)
,p_name=>'cred_id_sso'
,p_static_id=>'cred_id_sso'
,p_authentication_type=>'OAUTH2_CLIENT_CREDENTIALS'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
