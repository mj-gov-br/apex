prompt --workspace/credentials/cred_id_sso
begin
--   Manifest
--     CREDENTIAL: cred_id_sso
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>621082111493881309
,p_default_application_id=>123
,p_default_id_offset=>623399882648930452
,p_default_owner=>'WS_20251007103000'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(633439283234924692)
,p_name=>'cred_id_sso'
,p_static_id=>'cred_id_sso'
,p_authentication_type=>'OAUTH2_CLIENT_CREDENTIALS'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
