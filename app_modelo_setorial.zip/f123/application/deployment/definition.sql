prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 123
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>621082111493881309
,p_default_application_id=>123
,p_default_id_offset=>623399882648930452
,p_default_owner=>'WS_20251007103000'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(1382423741923026030)
,p_welcome_message=>unistr('O Installer deste aplicativo vai ajud\00E1-lo no processo de cria\00E7\00E3o de objetos de banco de dados e dados pr\00E9-implantados.')
,p_configuration_message=>unistr('\00C9 poss\00EDvel configurar os atributos a seguir do aplicativo.')
,p_build_options_message=>unistr('\00C9 poss\00EDvel incluir as op\00E7\00F5es de build a seguir.')
,p_validation_message=>unistr('As valida\00E7\00F5es a seguir ser\00E3o executadas para garantir que o sistema seja compat\00EDvel com este aplicativo.')
,p_install_message=>'Confirme se deseja instalar os objetos de suporte deste aplicativo.'
,p_upgrade_message=>'O instalador do aplicativo detectou que os objetos de suporte deste aplicativo foram instalados anteriormente. Este assistente vai conduzi-lo durante o processo de upgrade desses objetos de suporte.'
,p_upgrade_confirm_message=>'Confirme se deseja instalar os objetos de suporte deste aplicativo.'
,p_upgrade_success_message=>'Os objetos de suporte do aplicativo foram instalados.'
,p_upgrade_failure_message=>unistr('Falha na instala\00E7\00E3o de objetos de banco de dados e dados pr\00E9-implantados.')
,p_deinstall_success_message=>unistr('Desinstala\00E7\00E3o conclu\00EDda.')
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
);
wwv_flow_imp.component_end;
end;
/
