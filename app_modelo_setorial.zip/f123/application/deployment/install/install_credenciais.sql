prompt --application/deployment/install/install_credenciais
begin
--   Manifest
--     INSTALL: INSTALL-credenciais
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>621082111493881309
,p_default_application_id=>123
,p_default_id_offset=>623399882648930452
,p_default_owner=>'WS_20251007103000'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(623402574346942924)
,p_install_id=>wwv_flow_imp.id(1382423741923026030)
,p_name=>'credenciais'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    apex_credential.set_persistent_credentials(',
'        p_credential_static_id  => ''credenciais_prod'',',
'        p_client_id             => ''apex_prod'',',
'        p_client_secret         => ''f6fc688b-a2eb-48e6-964d-cd6556ede0ca'' ',
'    );',
'    COMMIT;',
'END;    '))
);
wwv_flow_imp.component_end;
end;
/
