prompt --application/shared_components/security/authentications/cred_id_sso
begin
--   Manifest
--     AUTHENTICATION: cred_id_sso
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>621082111493881309
,p_default_application_id=>123
,p_default_id_offset=>623399882648930452
,p_default_owner=>'WS_20251007103000'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(1382095485517060104)
,p_name=>'cred_id_sso'
,p_scheme_type=>'NATIVE_SOCIAL'
,p_attribute_01=>wwv_flow_imp.id(633439283234924692)
,p_attribute_02=>'OPENID_CONNECT'
,p_attribute_03=>'https://login.microsoftonline.com/eb090420-444c-43f7-91f2-4b8da6bfe8e1/v2.0/.well-known/openid-configuration'
,p_attribute_07=>'profile,email,offline_access'
,p_attribute_09=>'preferred_username'
,p_attribute_11=>'Y'
,p_attribute_13=>'Y'
,p_invalid_session_type=>'LOGIN'
,p_post_auth_process=>'prc_oauth_token'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_version_scn=>46782274
);
wwv_flow_imp.component_end;
end;
/
