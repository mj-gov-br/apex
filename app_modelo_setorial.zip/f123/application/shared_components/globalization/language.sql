prompt --application/shared_components/globalization/language
begin
--   Manifest
--     LANGUAGE MAP: 123
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>621082111493881309
,p_default_application_id=>123
,p_default_id_offset=>623399882648930452
,p_default_owner=>'WS_20251007103000'
);
null;
wwv_flow_imp.component_end;
end;
/
