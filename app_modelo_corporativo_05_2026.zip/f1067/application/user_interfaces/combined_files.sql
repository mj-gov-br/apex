prompt --application/user_interfaces/combined_files
begin
--   Manifest
--     COMBINED FILES: 1067
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591757339680659714
,p_default_application_id=>1067
,p_default_id_offset=>1606807709588805098
,p_default_owner=>'WS_CURSO10_AL4_010'
);
null;
wwv_flow_imp.component_end;
end;
/
