prompt --application/shared_components/navigation/lists/barra_de_navega��o
begin
--   Manifest
--     LIST: Barra de Navega��o
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591757339680659714
,p_default_application_id=>1067
,p_default_id_offset=>1606807709588805098
,p_default_owner=>'WS_CURSO10_AL4_010'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(6466622457280223761)
,p_name=>unistr('Barra de Navega\00E7\00E3o')
,p_list_status=>'PUBLIC'
,p_version_scn=>322473559
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6466634424802223804)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'&G_NOME_COMPLETO.'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-user'
,p_list_item_icon_attributes=>'class="u-textInitCap"'
,p_list_text_02=>'u-textInitCap'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6466634979420223804)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'---'
,p_list_item_link_target=>'separator'
,p_list_item_disp_cond_type=>'USER_IS_NOT_PUBLIC_USER'
,p_parent_list_item_id=>wwv_flow_imp.id(6466634424802223804)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6466635300588223804)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Sair'
,p_list_item_link_target=>'&LOGOUT_URL.'
,p_list_item_icon=>'fa-sign-out'
,p_list_item_disp_cond_type=>'USER_IS_NOT_PUBLIC_USER'
,p_parent_list_item_id=>wwv_flow_imp.id(6466634424802223804)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1606907885802853855)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Feedback'
,p_list_item_link_target=>'f?p=&APP_ID.:10020:&APP_SESSION.::&DEBUG.:10020:P10020_PAGE_ID:&APP_PAGE_ID.'
,p_list_item_icon=>'fa-comment-o'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'apex_util.feedback_enabled'
,p_list_item_disp_condition2=>'PLSQL'
,p_list_text_02=>'icon-only'
,p_required_patch=>wwv_flow_imp.id(1606869824101853825)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
