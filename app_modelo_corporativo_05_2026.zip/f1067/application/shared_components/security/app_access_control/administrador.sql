prompt --application/shared_components/security/app_access_control/administrador
begin
--   Manifest
--     ACL ROLE: Administrador
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1591757339680659714
,p_default_application_id=>1067
,p_default_id_offset=>1606807709588805098
,p_default_owner=>'WS_CURSO10_AL4_010'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(1606824979987852147)
,p_static_id=>'ADMINISTRADOR'
,p_name=>'Administrador'
,p_description=>'Role assigned to application administrators.'
,p_version_scn=>322494013
);
wwv_flow_imp.component_end;
end;
/
