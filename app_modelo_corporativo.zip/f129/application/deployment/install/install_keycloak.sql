prompt --application/deployment/install/install_keycloak
begin
--   Manifest
--     INSTALL: INSTALL-keycloak
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>416943639723963931
,p_default_application_id=>129
,p_default_id_offset=>623791763251663716
,p_default_owner=>'WS_CURSO05_PROFESSORES'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1247572591789184110)
,p_install_id=>wwv_flow_imp.id(3253420852288330093)
,p_name=>'keycloak'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_condition_type=>'ALWAYS'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE TB_USUARIO (',
'    NO_USUARIO VARCHAR2(250),',
'    DS_EMAIL   VARCHAR2(250),',
'    NR_CPF     VARCHAR2(14) PRIMARY KEY',
unistr('    -- Adicione outras colunas, como uma para definir o perfil de cada usu\00E1rio'),
');',
'/',
'create or replace PROCEDURE prc_oauth_token_keycloak',
'AS ',
'    l_expires_in NUMBER;',
'    l_token VARCHAR2(4000); ',
'    l_token_decoded apex_jwt.t_token; ',
'    l_count       PLS_INTEGER;',
'    v_app_id       VARCHAR2(10) := V(''APP_ID'');  ',
'    v_session_id   VARCHAR2(100) := V(''SESSION''); ',
'BEGIN ',
'/*',
unistr('    ESSE PROCEDIMENTO \00C9 CHAMADO COM O LOGIN SSO MICROSOFT, '),
unistr('    ELE RECEBE O TOKEN DO USU\00C1RIO, '),
unistr('    E COLOCA ITENS DE SESS\00C3O.'),
'*/',
'    l_count := apex_json.get_count(p_path => ''.'');  -- Conta os elementos no JSON raiz',
'    apex_debug.info(''Elementos no (JSON): %s'', l_count); ',
unistr('    -- Tenta recuperar token via apex_json (geralmente usado ap\00F3s parse JSON) '),
'    l_token := TRIM(apex_json.get_clob(''access_token'')); ',
'    l_expires_in := apex_json.get_number(''expires_in'');',
'    apex_debug.info(''Token recuperado (JSON): %s'', l_token); ',
unistr('    -- Define o token em um item de sess\00E3o'),
'    apex_util.set_session_state(''G_TOKEN'', l_token); ',
unistr('    --associando outros atributos na sess\00E3o:'),
'    l_token_decoded := apex_jwt.decode(p_value => l_token); ',
'    apex_debug.message(''------> '' || l_token_decoded.payload); ',
'    apex_util.set_session_state(''G_NOME_COMPLETO'', UPPER(json_value(l_token_decoded.payload, ''$.name''))); ',
'    apex_util.set_session_state(''G_IP_ADD'', json_value(l_token_decoded.payload, ''$.ipaddr'')); ',
'    apex_util.set_session_state(''G_ACCESS_TOKEN_TIME'', json_value(l_token_decoded.payload, ''$.exp'')); ',
'EXCEPTION ',
'    WHEN OTHERS THEN ',
'        apex_debug.error(''Erro ao recuperar token: %s'', SQLERRM); ',
'END prc_oauth_token_keycloak;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
