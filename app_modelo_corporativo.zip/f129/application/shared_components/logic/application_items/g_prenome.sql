prompt --application/shared_components/logic/application_items/g_prenome
begin
--   Manifest
--     APPLICATION ITEM: G_PRENOME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>416943639723963931
,p_default_application_id=>129
,p_default_id_offset=>623791763251663716
,p_default_owner=>'WS_CURSO05_PROFESSORES'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(3253094673617376223)
,p_name=>'G_PRENOME'
,p_protection_level=>'I'
,p_version_scn=>46758432
);
wwv_flow_imp.component_end;
end;
/
