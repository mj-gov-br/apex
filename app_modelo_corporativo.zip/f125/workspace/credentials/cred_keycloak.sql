prompt --workspace/credentials/cred_keycloak
begin
--   Manifest
--     CREDENTIAL: cred_keycloak
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>416943639723963931
,p_default_application_id=>125
,p_default_id_offset=>623777372569459635
,p_default_owner=>'WS_CURSO05_PROFESSORES'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(623780073855503836)
,p_name=>'cred_keycloak'
,p_static_id=>'cred_keycloak'
,p_authentication_type=>'OAUTH2_CLIENT_CREDENTIALS'
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
