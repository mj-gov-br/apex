prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 125
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>416943639723963931
,p_default_application_id=>125
,p_default_id_offset=>623777372569459635
,p_default_owner=>'WS_CURSO05_PROFESSORES'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(2629285239034483395)
,p_theme_id=>42
,p_name=>'MJSP'
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_Header-BG":"#ffffff","@g_Header-FG":"#333333","@g_Link-Base":"#1351b4","@g_Accent-BG":"#e6e6e6","@g_Focus":"#1351b4","@g_Body-BG":"#fdfdfd","@g_Body-Text":"#333333","@g_Actions-Col-BG":"#f9f9f9","@g_Actions-Col-Text":"#33333'
||'3","@g_Body-Title-BG":"#ffffff","@g_Body-Title-FG":"#333333","@g_Nav-BG":"#2c2f7a","@g_Nav-FG":"#fdfdfd","@g_Nav-Active-BG":"#2c2f7a","@g_Nav-Active-FG":"#ffffff","@g_Nav-Badge-BG":"#1351b4","@g_Nav-Badge-FG":"#ffffff","@Head-Height":"64px","@g_Disab'
||'led-BG":"#707070","@g_Disabled-FG":"#ffffff","@g_Warning-BG":"#f5ce14","@g_Warning-FG":"#000000","@g_Success-BG":"#009541","@g_Success-FG":"#ffffff","@g_Info-BG":"#2c2f7a","@g_Info-FG":"#ffffff","@Nav-Exp":"260px"},"customCSS":"@media (max-width: 768'
||unistr('px) { /* Afeta tablets e celulares */\005Cn  ul, ol {\005Cn    padding-left: 10px !important; /* Reduz a indenta\00E7\00E3o padr\00E3o */\005Cn    margin-left: 10px !important; /* Ajusta margem esquerda */\005Cn  }\005Cn\005Cn  li {\005Cn    padding-left: 5px; /* Reduz espa\00E7o dentro dos it')
||unistr('ens da lista */\005Cn    margin-left: 0; /* Remove margens extras */\005Cn  }\005Cn  #t-ContentRow-wrap {\005Cn    padding-left: 5px; /* Reduz espa\00E7o dentro dos itens da lista */\005Cn    margin-left: 0; /* Remove margens extras */\005Cn  }\005Cn}\005Cn\005Cn/* Altera o footer para azu')
||'l*/\n.t-Footer {\n  background-color: #2c2f7a !important;\n  color: white !important;\n  text-align: center;\n  padding: 10px 0;\n  font-size: 14px;\n}\n","useCustomLess":"Y"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#135372956942878192.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp.component_end;
end;
/
