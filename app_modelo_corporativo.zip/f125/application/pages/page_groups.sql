prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 125
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>416943639723963931
,p_default_application_id=>125
,p_default_id_offset=>623777372569459635
,p_default_owner=>'WS_CURSO05_PROFESSORES'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2629246502718051896)
,p_group_name=>unistr('Administra\00E7\00E3o')
);
wwv_flow_imp.component_end;
end;
/
