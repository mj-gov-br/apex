prompt --application/shared_components/security/authentications/keycloak
begin
--   Manifest
--     AUTHENTICATION: keycloak
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>416943639723963931
,p_default_application_id=>129
,p_default_id_offset=>888457892239958055
,p_default_owner=>'WS_CURSO05_PROFESSORES'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(1247571564444161336)
,p_name=>'keycloak'
,p_scheme_type=>'NATIVE_SOCIAL'
,p_attribute_01=>wwv_flow_imp.id(623780073855503836)
,p_attribute_02=>'OAUTH2'
,p_attribute_04=>'https://sso.mj.gov.br/auth/realms/HML/protocol/openid-connect/auth'
,p_attribute_05=>'https://sso.mj.gov.br/auth/realms/HML/protocol/openid-connect/token'
,p_attribute_07=>'email profile'
,p_attribute_09=>'preferred_username'
,p_attribute_11=>'N'
,p_attribute_12=>'BASIC_AND_CLID'
,p_attribute_13=>'Y'
,p_invalid_session_type=>'LOGIN'
,p_post_auth_process=>'SP_OAUTH_TOKEN_KEYCLOAK'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_version_scn=>197991160
);
wwv_flow_imp.component_end;
end;
/
