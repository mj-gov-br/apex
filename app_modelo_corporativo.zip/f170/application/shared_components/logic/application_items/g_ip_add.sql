prompt --application/shared_components/logic/application_items/g_ip_add
begin
--   Manifest
--     APPLICATION ITEM: G_IP_ADD
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>416943639723963931
,p_default_application_id=>129
,p_default_id_offset=>888457892239958055
,p_default_owner=>'WS_CURSO05_PROFESSORES'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(3253095117554381705)
,p_name=>'G_IP_ADD'
,p_protection_level=>'I'
,p_version_scn=>46758501
);
wwv_flow_imp.component_end;
end;
/
