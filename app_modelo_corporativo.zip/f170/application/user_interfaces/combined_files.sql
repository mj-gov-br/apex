prompt --application/user_interfaces/combined_files
begin
--   Manifest
--     COMBINED FILES: 170
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>416943639723963931
,p_default_application_id=>129
,p_default_id_offset=>888457892239958055
,p_default_owner=>'WS_CURSO05_PROFESSORES'
);
null;
wwv_flow_imp.component_end;
end;
/
