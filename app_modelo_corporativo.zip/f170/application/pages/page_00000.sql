prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>416943639723963931
,p_default_application_id=>129
,p_default_id_offset=>888457892239958055
,p_default_owner=>'WS_CURSO05_PROFESSORES'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>unistr('P\00E1gina Global')
,p_step_title=>unistr('P\00E1gina Global')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1311541026143631)
,p_plug_name=>unistr('Cabe\00E7alho MJSP')
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_07'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'    body {',
'        margin: 0;',
'        font-family: Arial, sans-serif;',
'    }',
'',
'    /* Header azul */',
'    .top-bar {',
'        width: 100%;',
'        height: 35px;',
'        background: #1351b4; /* azul igual ao da imagem */',
'        display: flex;',
'        align-items: center;',
'        padding: 0 10px;',
'        box-sizing: border-box;',
'    }',
'',
unistr('    /* \00C1rea do logo + t\00EDtulo */'),
'    .top-bar-content {',
'        display: flex;',
'        align-items: center;',
'        gap: 12px;',
'    }',
'',
'    .top-bar svg {',
'        height: 24px;',
'        fill: white;',
'    }',
'',
'</style>',
'<div class="top-bar hidden-sm-down">',
'    <div class="top-bar-content">',
'',
'        <!-- SVG semelhante ao da imagem -->',
'        <img style="height: 35px;" alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQMAAAC/CAYAAAD6rrlxAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAACHDwAAjA8AAP1SAACBQAAAfXkAAOmLAAA85QAAGcxzPIV3AAAKL2lDQ1BJQ0MgUHJvZmlsZQAASMedlndUVNcWh8+9d3qhzTDSGXqTL'
||'jCA9C4gHQRRGGYGGMoAwwxNbIioQEQREQFFkKCAAaOhSKyIYiEoqGAPSBBQYjCKqKhkRtZKfHl57+Xl98e939pn73P32XuftS4AJE8fLi8FlgIgmSfgB3o401eFR9Cx/QAGeIABpgAwWempvkHuwUAkLzcXerrICfyL3gwBSPy+ZejpT6eD/0/SrFS+AADIX8TmbE46S8T5Ik7KFKSK7TMipsYkihlGiZkvSlDEcmKOW+Sln30W2VHM7GQ'
||'eW8TinFPZyWwx94h4e4aQI2LER8QFGVxOpohvi1gzSZjMFfFbcWwyh5kOAIoktgs4rHgRm4iYxA8OdBHxcgBwpLgvOOYLFnCyBOJDuaSkZvO5cfECui5Lj25qbc2ge3IykzgCgaE/k5XI5LPpLinJqUxeNgCLZ/4sGXFt6aIiW5paW1oamhmZflGo/7r4NyXu7SK9CvjcM4jW94ftr/xS6gBgzIpqs+sPW8x+ADq2AiB3/w+b5iEAJEV9a'
||'7/xxXlo4nmJFwhSbYyNMzMzjbgclpG4oL/rfzr8DX3xPSPxdr+Xh+7KiWUKkwR0cd1YKUkpQj49PZXJ4tAN/zzE/zjwr/NYGsiJ5fA5PFFEqGjKuLw4Ubt5bK6Am8Kjc3n/qYn/MOxPWpxrkSj1nwA1yghI3aAC5Oc+gKIQARJ5UNz13/vmgw8F4psXpjqxOPefBf37rnCJ+JHOjfsc5xIYTGcJ+RmLa+JrCdCAACQBFcgDFaABdIEhMAN'
||'WwBY4AjewAviBYBAO1gIWiAfJgA8yQS7YDApAEdgF9oJKUAPqQSNoASdABzgNLoDL4Dq4Ce6AB2AEjIPnYAa8AfMQBGEhMkSB5CFVSAsygMwgBmQPuUE+UCAUDkVDcRAPEkK50BaoCCqFKqFaqBH6FjoFXYCuQgPQPWgUmoJ+hd7DCEyCqbAyrA0bwwzYCfaGg+E1cBycBufA+fBOuAKug4/B7fAF+Dp8Bx6Bn8OzCECICA1RQwwRBuKC+'
||'CERSCzCRzYghUg5Uoe0IF1IL3ILGUGmkXcoDIqCoqMMUbYoT1QIioVKQ21AFaMqUUdR7age1C3UKGoG9QlNRiuhDdA2aC/0KnQcOhNdgC5HN6Db0JfQd9Dj6DcYDIaG0cFYYTwx4ZgEzDpMMeYAphVzHjOAGcPMYrFYeawB1g7rh2ViBdgC7H7sMew57CB2HPsWR8Sp4sxw7rgIHA+XhyvHNeHO4gZxE7h5vBReC2+D98Oz8dn4Enw9vgt'
||'/Az+OnydIE3QIdoRgQgJhM6GC0EK4RHhIeEUkEtWJ1sQAIpe4iVhBPE68QhwlviPJkPRJLqRIkpC0k3SEdJ50j/SKTCZrkx3JEWQBeSe5kXyR/Jj8VoIiYSThJcGW2ChRJdEuMSjxQhIvqSXpJLlWMkeyXPKk5A3JaSm8lLaUixRTaoNUldQpqWGpWWmKtKm0n3SydLF0k/RV6UkZrIy2jJsMWyZf5rDMRZkxCkLRoLhQWJQtlHrKJco4F'
||'UPVoXpRE6hF1G+o/dQZWRnZZbKhslmyVbJnZEdoCE2b5kVLopXQTtCGaO+XKC9xWsJZsmNJy5LBJXNyinKOchy5QrlWuTty7+Xp8m7yifK75TvkHymgFPQVAhQyFQ4qXFKYVqQq2iqyFAsVTyjeV4KV9JUCldYpHVbqU5pVVlH2UE5V3q98UXlahabiqJKgUqZyVmVKlaJqr8pVLVM9p/qMLkt3oifRK+g99Bk1JTVPNaFarVq/2ry6jnq'
||'Iep56q/ojDYIGQyNWo0yjW2NGU1XTVzNXs1nzvhZei6EVr7VPq1drTltHO0x7m3aH9qSOnI6XTo5Os85DXbKug26abp3ubT2MHkMvUe+A3k19WN9CP16/Sv+GAWxgacA1OGAwsBS91Hopb2nd0mFDkqGTYYZhs+GoEc3IxyjPqMPohbGmcYTxbuNe408mFiZJJvUmD0xlTFeY5pl2mf5qpm/GMqsyu21ONnc332jeaf5ymcEyzrKDy+5aU'
||'Cx8LbZZdFt8tLSy5Fu2WE5ZaVpFW1VbDTOoDH9GMeOKNdra2Xqj9WnrdzaWNgKbEza/2BraJto22U4u11nOWV6/fMxO3Y5pV2s3Yk+3j7Y/ZD/ioObAdKhzeOKo4ch2bHCccNJzSnA65vTC2cSZ79zmPOdi47Le5bwr4urhWuja7ybjFuJW6fbYXd09zr3ZfcbDwmOdx3lPtKe3527PYS9lL5ZXo9fMCqsV61f0eJO8g7wrvZ/46Pvwfbp'
||'8Yd8Vvnt8H67UWslb2eEH/Lz89vg98tfxT/P/PgAT4B9QFfA00DQwN7A3iBIUFdQU9CbYObgk+EGIbogwpDtUMjQytDF0Lsw1rDRsZJXxqvWrrocrhHPDOyOwEaERDRGzq91W7109HmkRWRA5tEZnTdaaq2sV1iatPRMlGcWMOhmNjg6Lbor+wPRj1jFnY7xiqmNmWC6sfaznbEd2GXuKY8cp5UzE2sWWxk7G2cXtiZuKd4gvj5/munAru'
||'S8TPBNqEuYS/RKPJC4khSW1JuOSo5NP8WR4ibyeFJWUrJSBVIPUgtSRNJu0vWkzfG9+QzqUvia9U0AV/Uz1CXWFW4WjGfYZVRlvM0MzT2ZJZ/Gy+rL1s3dkT+S453y9DrWOta47Vy13c+7oeqf1tRugDTEbujdqbMzfOL7JY9PRzYTNiZt/yDPJK817vSVsS1e+cv6m/LGtHlubCyQK+AXD22y31WxHbedu799hvmP/jk+F7MJrRSZF5UU'
||'filnF174y/ariq4WdsTv7SyxLDu7C7OLtGtrtsPtoqXRpTunYHt897WX0ssKy13uj9l4tX1Zes4+wT7hvpMKnonO/5v5d+z9UxlfeqXKuaq1Wqt5RPXeAfWDwoOPBlhrlmqKa94e4h+7WetS212nXlR/GHM44/LQ+tL73a8bXjQ0KDUUNH4/wjowcDTza02jV2Nik1FTSDDcLm6eORR67+Y3rN50thi21rbTWouPguPD4s2+jvx064X2i+'
||'yTjZMt3Wt9Vt1HaCtuh9uz2mY74jpHO8M6BUytOdXfZdrV9b/T9kdNqp6vOyJ4pOUs4m3924VzOudnzqeenL8RdGOuO6n5wcdXF2z0BPf2XvC9duex++WKvU++5K3ZXTl+1uXrqGuNax3XL6+19Fn1tP1j80NZv2d9+w+pG503rm10DywfODjoMXrjleuvyba/b1++svDMwFDJ0dzhyeOQu++7kvaR7L+9n3J9/sOkh+mHhI6lH5Y+VHtf'
||'9qPdj64jlyJlR19G+J0FPHoyxxp7/lP7Th/H8p+Sn5ROqE42TZpOnp9ynbj5b/Wz8eerz+emCn6V/rn6h++K7Xxx/6ZtZNTP+kv9y4dfiV/Kvjrxe9rp71n/28ZvkN/NzhW/l3x59x3jX+z7s/cR85gfsh4qPeh+7Pnl/eriQvLDwG/eE8/s3BCkeAAAACXBIWXMAAC4iAAAuIgGq4t2SAAAQSklEQVR4Xu3dfXRUZ50HcObOTJIJIYEQK'
||'GxqkEoLpXW74KldtJbWdsWX3S1CrJ4e27Nu7dl2FevL8aVWoMkfHg56pFpka6UeracWEShb69FWpQgFrVaifSFQXhODBFJC3uflzp3Z7/Pcn5IsM8lN5v3e7+ec59zfc2cgc+/M853nztyZ8SUSieSk4pNA+z3aLty+fZFI5KXJkyef1ZcUQCwWuzwYDL4u3UI7ifZcMpncZ5rm/nXr1h1fu3at2l8FgdvxKhZX2b2i0o2m9tNey7L2Hzl'
||'y5ODChQtj9kX5h9uxGYu77F7RsNBeRHtejbNiCgP1gH4eO23r0NDQU1VVVV326sIrgjBQf/vJeDz+E9yO1+xVxaHIwkA9YWzF4N+6c+fO/Y2NjerBXhSKKAzUPvmVGmeDg4P/O2XKlHP26kmTiiEMzqM9igH3aHl5+XF7VXEpUBioO20H7p9N+Nu/KaLQHqFIwmA/bsc3Dx06tLOQz/6jKYIwUIP+kWg0+t2Kioo2e9VIhiwL4Rx20Bffe'
||'OONBp/P96ViDYICUCHwfQTQfOyX2/x+/+5iDYIisAuzgOuxn95pGMbWYg2CAuvCOPtsZ2enGmdfSRcESiHCQN1h63t7e9+CO3D9jBkzBuzVBM/hUOAa3GkfQzgek3V0sdcQkO/Ffro5EAjsk3U0UgTtq93d3WqcbZg9e/aQvTq9fIfBC6Zpqgf7F6dOndor62jSpNN4cK/EfllWbK8JFJmwmk3u2bPnnzBjelbW0cV2YWb5VjyeHpg+fXq'
||'/rBtTvsIgijvx883NzUvLysoOyTqybevv778aD+4d0qfUDuCJZJGaTS5dujQu62ikCMbZKjyWbsHM8qiscywfYXACU9934E78eiHfAitCKiDvRXp/qLq6Wr0NRultbG1tXYInksPSp4sdxTi7DuNs40RfY8p1GOweGBi4FlPfA9In2xnLsm7EHfeI9Cm1GALzYwjMVXxxcFTP9fX1qXH2svQnJJdh8ATSfNnw9zFJO4zjuSWBQOB30qfU+'
||'vAMtwyB+X3pU2rf27Nnzwdqamp6pD9huQqD7zQ3N9/JNL/IK0NDQ0txPHdC+pRaN2ZON6u3VaVPqX0L++jj2XoNJRdh8Bhu4L18feAihxAEt0yePPmM9Cm1PgTBMsycXpI+pbYJh0/3ZfMclGyHwc7t27f/VzZvoEucikQi/1LIz1eUiBgeO7cyCMa0BTPvVVJnTTZPR36ps7NzqZOTG0pNhqcjD8bj8Xfh37dI31WSWTwdGf/XnYZh/FC'
||'6roJty9bpyPvb29tvnjNnjjqpKKuyNTPoikajK90YBJnCg+Djbg2CLHvIrUGQRafD4XBjLoJAyUYYJDG7uKOioqJd+nTBJjzAt0hN6b3Y0tLyBakpNQyzxO2VlZWnpZ912QiDh/08NTSVQzhs+rzUlN4gDsM+unjxYlP6lNrXcv3uSqZhcPzs2bNflpouSFiWdRcPm8aGw6ivTOTUWY853N7e/qDUOZNRGGDa8slLLrlkULp0wXcDgcB+q'
||'Sm9Azt27HhYakoD4+zeXL1OMFwmYfAzTFt+LjVd0DM4OLhaahoFZk+fLqZvIypS2zHOnpc6pyYaBol4PH6/1DQMpr1fL6avbCtiz2D2tFdqSs0yTfMBqXNuomGwPRgMviI1XdB9/vz5b0lNo8CsIOfHwC7wo3x+UnNCYYA7cr2UNNKm8XyZhIf9CrOCP0pNqSUx+87rOJtIGLzA00VTMsPh8LelplEkEomHpKT0fo3Ztzq7M2/GHQY4Jn5'
||'UShrpp5WVlZ1SU3p/eeqpp34hNaVRiHE23jAY7Orq4tdzpYBnu8elpNE9wXcQxtR7/Pjxp6XOm/GGwTM8ryClvo6ODp6F6QCOg7dKSentnDdvXlTqvBlXGGDq8lMpaaRn83FSiAv8hR/aGhtmmQUZZ+MJg8TQ0BCf/VJASPIY2Bnup7HFe3t7fyl1Xo0nDFqrqqrekJqGMU1zj5Q0CoQm99PY/lxbW9sndV6NJwx4rn1qZ/lBG2cQmr+Vk'
||'tIr2DhzHAZI9T9JSSP9WZY0ut5QKMTf0xxDIceZ4zBIJBJ5PQGihHC/OKN+H5HfjTmGQo4zx2GAKR5TPQUkOfeLM/x6eAcikUjBHk9OwyC+fv36v0pNwyAM+HVvzqT9KXD6u6FCvkjvNAzO8XcQUkMY8OPKDmA/8Z2osRX0seQ0DM7Lkv4fHONx3zjD/TS2gu4jp2GQ91MjSwWe8XjmoTPcT2Mr6DhzGgb85to0MDPgvnEAocn9NLaC/ja'
||'p0zDgW0JELuc0DIjI5RgGRKQxDIhIYxgQkcYwICKNYUBEGsOAiDSGARFpDAMi0hgGRKQxDIhIYxgQkcYwICKNYUBEGsOAiDSGARFpDAMi0hgGRKQxDIhIYxgQkcYwICKNYUBEGsOAiDSGARFpDAMi0hgGGfL5fH4pvcrr2+8aDIMMGYZRJaVXeX37XYNhkCGEQbWUXuX17XcNhkGGEAZvltJz+vr6arFgGLgEwyBz82XpOZWVlQukJBdgG'
||'GTI5/O9TUrPwaxosZTkAgyDzN2wbds2T76ijiB8t5TkAgyDzNUsX758idSecfTo0XIsbrJ75AYMgyzw+/13SOkZc+fO/Vcspto9cgOGQXbc1tXV5an32w3D+E8pySUYBtkxdfr06fdI7XqmaV6DxfvsHrkFwyBLfD7f57wyOwgEAqux8Nk9cguGQfbMqqurU4PE1SzLugWLlXaP3IRhkF2fwRT6H6V2ndOnT1cahrFRuuQyDIPsCmIKveX'
||'MmTOTpe8qs2bNehgLz55x6XYMg+y7cubMmd9rampy1b5NJBJ3Y8F3EFyMYZAbt61Zs+YhqUueZVnLfT7f/0iXXIphkDurksnkN0t9hoAZwYcMw9iCkl9i4nIMg9z6FGYIPyrV1xAQBPdhRvAkSnXqMbkcwyD3Pjxz5swXTdO8SvpFr6enpwazmp8gCNShDmcEHsEwyI+rAoHAHzHAmjo6OkKyrihhNnB7TU1NK8pGew15BcMgf9RUe019f'
||'f0hDLj/bmtrq7BXF55hGD7Lst6PsNqH2cATWDXbvoS8hGGQfw0YcN9uaGhow+DbgMOHxWowymV5FQ6HL0UwfQFB8DJuw8+w6h32JeRFPjwYklKP5g94AL9das+JxWKXB4PB16WbC51ouxEO6lBCzRxOxOPx3mg02o+wsOyrTIzf7zdCoVAVlqr9A+7HBWjqg0Y3ouXta8uwTY34+9ul6zm4XzdjcZfdS2sv7psbpM47hoEDeQgD12MYFH8'
||'Y8DCBiDSGARFpDAMi0hgGRKQxDDKUTCY/g8UuVeoV3qC29Xey7Sf0Gip5DIMMRaNRddruzbFY7C3oNqMd0xe4TwLt9wiA+7Gtl2GblxiGoU5XHtKXUsljGGRJeXn5CQyQtWjz4vG4+pWlr6Id0ReWrkG0pxEAd4fD4Xps23UIgHXY1pP2xeQmDIMcCAaDBzBwHkC7wjTN+RhMq7D6GbQBfYXiFUFTJz+ttSzrXa2trbXYhlsRAJsrKyvVi'
||'VHkYgyDHCsrK3sdg2kjBtW/tbS01GKQXYvBdh8uUt8RoJ5hC/VaQxztINrjKqxwu647duzYVNzOm3B7mwOBwAsLFy6M6WuSJ/AMRAdGOwMxEolcGgqFTkl33Lq7u6vhagzAq7GP1enBc9EapNWhZUIN5g60drSTGPQqfFox8A+2tbUdmTdvXhT9jOD/fBWLMT+ezTMQeTqyK+QyDEajvo142rRpdRhEtQiLWqyqwf2gPv1YJk3N7NSAj+H'
||'BppaDWJ7DYO+ORqPdGzZs6Fm7dq164S9nGAbOMAxcolBhUAoYBs6UQhjwNQMi0hgGRKQxDIhIYxgQkcYwICKNYUBEGsOAiDSGARFpDAMi0hgGRKQxDIhIYxgQkcYwICKNYUBEGsOAiDSGARFpDAMi0hgGRKQxDIhIYxgQkcYwICKNYUBEGsOAiDSGARFpDAMi0hgGRKQxDIhIcxoGFbL0JPmxUyJXcxoGU2TpSQgDT28/eYPTMFA/B+5ZC'
||'IPpUhK5ltMwqB4aGpoltecgDK6Qksi1HL+AWF5efqWUnoMwWCAlkWs5DgMMiOul9CIvbzt5xHjC4N1SegoOj2Zj4dlZEXmH4zCAdw4ODs6U2jMqKipWSEnkauMJg2AoFLpdas/AjOhOKYlcbTxhoAbGPU1NTeP6N6UsHo9fi8Xb7R6Ru413YM9fvXp1o9Su5/f7H5CSyPXG/SyP2UHTwYMHy6TrWpgV/DMW/273iNxvIlP+BfBZqV1p27Z'
||'tmBT4N6H02WuI3G9Cx/+YHawxTfOt0nWdFStW3I/FIrtH5A0TfTEwFAgEftzV1VUlfdewLOtGhN2D0iXyjImGgXJlXV3djw8cOBCUfsmLxWILDMPYhtJvryHyjkzCQHn/okWLHlPH2NIvWZFIZE4wGPwFSn5CkTwp0zBQ7li5cuXWtra2kv0CFNM0ry4vL9+Hco69hsh7shEGyoqGhoZdeHZtkH7JsCxreSAQ2Iuy3l5D5E3ZCgNlCZ5dW'
||'xKJxIelX9TOnTs3JZlMPmwYxg50p9pribwrm2Gg1Pp8vi0YZM/GYrGFsq6oqNOpEVgfqa2tbUX3k2g8l4AIsh0Gf/OeYDD4CkJhu5zJV3AdHR0hhMAda9aseRmB9SRW8bCAaJhchYGi/u8Vfr//twiFw2gPIhiuz+epzAMDA3WWZTXibz9WX1/fiRB4HKuvsi8louF8eLZMSp0vYbTDaIfQ/orWj8E6gGWmAhjs6luMa9Dmos2XZS4DT70'
||'leWkoFDolXc/BffcqFmMGLB5njXhi2C5dz8F+2ozFXXYvrb14DN8gdd4VIgxchWHAMHCiFMIgp8+aRFQ6GAZEpDEMiEhjGBCR5jQMetDO2KXnqBdYX7NLIvdyGgZHWlpa3pRIJD6I+mm0uF7rbn9KJpP3x2Kxy0zTVNtN5GqODxMWL15s+v3+nT6f79ZwOPwmDJRPYPVutIS+QulTAbcb2/U5DP4rsJ2LDMNYV15eftK+mMjdJvSaQWVlZ'
||'ScGyiYMmJsQDPUYQPdg9U60Pn2F0nEUbTNu/+39/f0z1fZgu75RVlZ2xL6YyDsyfgFRguE7GEgfxKGEOv13KQaX+tqw59CKKRxMtANoj+D2/Uc0Gn0zbvPlaHfj9j9ZXV19Xl+LyKMyDoPh1KFEIBDYg8HVhEG2rLm5eVo8Hr8Gg0+defUNNBUQp9V1c6wTbRfaRvztTyCgrj916lQNbtPb0O7F7ftBRUVFm74mEWlOT0f+AwZR1n5ZSH2'
||'XAJ6J52JQXob/dw6a+g3HOrRatGlok9HUB5r+1tTrErFhTc041Dsc3aphwJ9Ga8e2nOzp6Tk5Y8aMbHzW4e9isdjlwWDwdemOwNOReTqyE9hPrvlsQlbDoNQwDNJjGDhTCmGQ1cMEIipdDAMi0hgGRKQxDIhIYxgQkcYwICKNYUBEGsOAiDSGARFpDAMi0hgGRKQxDIhIYxgQkcYwICKNYUBEGsOAiDSGARFpDAMi0hgGRKQxDIhIYxgQk'
||'cYwICKNYUBEGsOAiDSGARHBpEn/B9Jd9cIKJKqhAAAAAElFTkSuQmCC">',
'',
'        <span class="u-text-muted-color" >',
unistr('            <a href="https://www.gov.br/mj/pt-br" target="_blank" style="color: #fff; font-family: Raleway;">Minist\00E9rio da Justi\00E7a e Seguran\00E7a P\00FAblica</a>'),
'        </span>',
'',
'    </div>',
'</div>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
